<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Панель управления | CleanPro</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">CleanPro <span>System</span></div>
        <div class="nav-links">
            <a href="#">Главная</a>
            <a href="#">Услуги</a>
        </div>
    </nav>

    <main class="hero-section">
        <div class="hero-content">
            <h1>Добро пожаловать в систему</h1>
            <p class="subtitle">Управляйте заявками на клининг быстро и удобно.</p>
            
            <div class="auth-panel">
                <a href="login.php" class="btn btn-outline">Вход в систему</a>
                <a href="register.php" class="btn btn-solid">Создать аккаунт</a>
            </div>

            <div class="system-status">
                <p><strong>Статус сервера:</strong> Онлайн</p>
                <p><strong>Дата:</strong> <?= date('d.m.Y') ?> | <strong>Версия PHP:</strong> <?= PHP_VERSION ?></p>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <p>&copy; 2026 CleanPro. Все права защищены.</p>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>